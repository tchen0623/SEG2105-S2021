package seg2105.s2021.studentcoursebookingapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private UserDBHelper userDBHelper;
    private CourseDBHelper courseDBHelper;
    private SQLiteDatabase userDB;
    private SQLiteDatabase courseDB;
    public String user_name, user_password, user_type;

    public MainActivity() {
        user_type = "";
        user_password = "";
        user_name = "";
    }

    public void setUserDBHelper(UserDBHelper userDBHelper) { this.userDBHelper = userDBHelper; }
    public void setCourseDBHelper(CourseDBHelper courseDBHelper) { this.courseDBHelper = courseDBHelper; }
    public void setUserDB(SQLiteDatabase userDB) { this.userDB = userDB; }
    public void setCourseDB(SQLiteDatabase courseDB) { this.courseDB = courseDB; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setUserDBHelper(new UserDBHelper(this, "users.db", null, 1));
        setCourseDBHelper(new CourseDBHelper(this, "courses.db", null, 1));
        setUserDB(userDBHelper.getWritableDatabase());
        setCourseDB(courseDBHelper.getWritableDatabase());

        Cursor cursor = userDB.query("user", null, "user_type=?", new String[]{"admin"}, null, null, null);
        if (cursor.getCount() == 0) {
            ContentValues values = new ContentValues();
            values.put("user_type", "admin");
            values.put("user_name", "admin");
            values.put("user_password", "admin123");
            userDB.insert("user", null, values);
            values.clear();
        }
        cursor.close();

        TextView title = (TextView) findViewById(R.id.sign_title);
        EditText name = (EditText) findViewById(R.id.name);
        EditText password = (EditText) findViewById(R.id.password);
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.user_type_group);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.botton_admin:
                        user_type = "admin";
                        break;
                    case R.id.botton_instructor:
                        user_type = "instructor";
                        break;
                    case R.id.botton_student:
                        user_type = "student";
                        break;
                }
            }
        });

        Button sign_in = (Button) findViewById(R.id.botton_sign_in);
        Button sign_up = (Button) findViewById(R.id.botton_sign_up);
        sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                user_name = name.getText().toString().trim();
                user_password = password.getText().toString().trim();
                Cursor cursor = userDB.query("user", null, "user_name=?", new String[]{user_name}, null, null, null);
                if (cursor.getCount() == 0){
                    intent.setClass(MainActivity.this, ErrorActivity.class);
                    intent.putExtra("error", Error.userNameError.getText());
                }
                else {
                    cursor.moveToFirst();
                    String _password = cursor.getString(cursor.getColumnIndex("user_password"));
                    String _type = cursor.getString(cursor.getColumnIndex("user_type"));
                    if (user_password.equals(_password)) {
                        if (user_type.equals(_type)) {
                            intent.setClass(MainActivity.this, SignInActivity.class);
                            intent.putExtra("name", user_name);
                            intent.putExtra("type", user_type);
                        } else {
                            intent.setClass(MainActivity.this, ErrorActivity.class);
                            intent.putExtra("error", Error.userTypeError.getText());
                        }
                    } else {
                        intent.setClass(MainActivity.this, ErrorActivity.class);
                        intent.putExtra("error", Error.userPasswordError.getText());
                    }
                }
                cursor.close();
                startActivity(intent);
            }
        });
        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                user_name = name.getText().toString().trim();
                user_password = password.getText().toString().trim();
                Cursor cursor = userDB.query("user", null, "user_name=?", new String[]{user_name}, null, null, null);
                if (cursor.getCount() == 0) {
                    ContentValues values=new ContentValues();
                    values.put("user_type", user_type);
                    values.put("user_name", user_name);
                    values.put("user_password", user_password);
                    userDB.insert("user", null, values);
                    intent.setClass(MainActivity.this, SignUpActivity.class);
                    intent.putExtra("name", user_name);
                    intent.putExtra("type", user_type);
                }
                else {
                    intent.setClass(MainActivity.this, ErrorActivity.class);
                    intent.putExtra("error", Error.userNameExists.getText());
                }
                cursor.close();
                startActivity(intent);
            }
        });

    }

}