package seg2105.s2021.studentcoursebookingapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CreateCourseActivity extends AppCompatActivity {

    public String course_code = "", course_name = "";
    private SQLiteDatabase userDB;
    private SQLiteDatabase courseDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_course);
        UserDBHelper userDBHelper = new UserDBHelper(this, "users.db", null, 1);
        CourseDBHelper courseDBHelper = new CourseDBHelper(this, "courses.db", null, 1);
        userDB = userDBHelper.getWritableDatabase();
        courseDB = courseDBHelper.getWritableDatabase();
        TextView admin_mode1 = (TextView) findViewById(R.id.admin_mode1);
        TextView create_course = (TextView) findViewById(R.id.create_course);
        EditText course_code1 = (EditText) findViewById(R.id.course_code1);
        EditText course_name1 = (EditText) findViewById(R.id.course_name1);
        TextView success = (TextView) findViewById(R.id.success1);
        Button button_forward1 = (Button) findViewById(R.id.button_forward1);
        Button button_backward1 = (Button) findViewById(R.id.button_backward1);
        button_forward1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                course_code = course_code1.getText().toString().trim();
                course_name = course_name1.getText().toString().trim();
                Cursor cursor = courseDB.query("course", null, "course_name=?", new String[]{course_name}, null, null, null);
                if (cursor.getCount() == 0) {
                    ContentValues values=new ContentValues();
                    values.put("course_code", course_code);
                    values.put("course_name", course_name);
                    courseDB.insert("course", null, values);
                    success.setText(String.format("Successfully create course %s, %s", course_code, course_name));
                }
                else {
                    success.setText(Error.courseNameExists.getText());
                }
                cursor.close();
            }
        });
        button_backward1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(CreateCourseActivity.this, AdminActivity.class);
                startActivity(intent);
            }
        });
    }

}
