package seg2105.s2021.studentcoursebookingapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShowAllCoursesActivity extends AppCompatActivity {

    public String course_code = "", course_name = "";
    private SQLiteDatabase userDB;
    private SQLiteDatabase courseDB;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all_courses);
        UserDBHelper userDBHelper = new UserDBHelper(this, "users.db", null, 1);
        CourseDBHelper courseDBHelper = new CourseDBHelper(this, "courses.db", null, 1);
        userDB = userDBHelper.getReadableDatabase();
        courseDB = courseDBHelper.getReadableDatabase();

        Intent intent = getIntent();
        name = intent.getStringExtra("name");

        ListView list_all_courses = (ListView) findViewById(R.id.list_all_courses);
        List<Map<String, Object>> listItemsList = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("number", "number");
        map.put("code", "code");
        map.put("name", "name");
        listItemsList.add(map);
        @SuppressLint("Recycle") Cursor cursor = courseDB.rawQuery("select * from course", null);
        while (cursor.moveToNext()) {
            map = new HashMap<String, Object>();
            map.put("number", cursor.getString(0));
            map.put("code", cursor.getString(1));
            map.put("name", cursor.getString(2));
            listItemsList.add(map);
        }

        SimpleAdapter adapter = new SimpleAdapter(this, listItemsList, R.layout.list_course, new String[]{"number", "code", "name"}, new int[]{R.id.data_course_number, R.id.data_course_code, R.id.data_course_name});
        list_all_courses.setAdapter(adapter);

        Button button_backward5 = (Button) findViewById(R.id.button_backward5);
        button_backward5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(ShowAllCoursesActivity.this, InstructorActivity.class);
                intent.putExtra("name", name);
                startActivity(intent);
            }
        });
    }
}
