package seg2105.s2021.studentcoursebookingapp;

import androidx.core.graphics.drawable.IconCompat;

public enum Error {
    userNameError("user name error"), userPasswordError("user password error"), userTypeError("user type error"),
    userNameExists("user name exists"), courseNameExists("course name exists"), courseNameError("course name error"),
    courseCodeError("course code error"), searchCourseError("search course error");

    private final String text;

    Error(String _text){
        this.text = _text;
    }

    public String getText(){
        return text;
    }

}
