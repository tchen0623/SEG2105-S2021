package seg2105.s2021.studentcoursebookingapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DeleteUserActivity  extends AppCompatActivity {

    public String user_name = "";
    private SQLiteDatabase userDB;
    private SQLiteDatabase courseDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_user);
        UserDBHelper userDBHelper = new UserDBHelper(this, "users.db", null, 1);
        CourseDBHelper courseDBHelper = new CourseDBHelper(this, "courses.db", null, 1);
        userDB = userDBHelper.getWritableDatabase();
        courseDB = courseDBHelper.getWritableDatabase();
        TextView admin_mode4 = (TextView) findViewById(R.id.admin_mode4);
        TextView delete_user = (TextView) findViewById(R.id.delete_user);
        EditText delete_user_name = (EditText) findViewById(R.id.delete_user_name);
        TextView success = (TextView) findViewById(R.id.success4);
        Button button_forward4 = (Button) findViewById(R.id.button_forward4);
        Button button_backward4 = (Button) findViewById(R.id.button_backward4);
        button_forward4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_name = delete_user_name.getText().toString().trim();
                Cursor cursor = userDB.query("user", null, "user_name=?", new String[]{user_name}, null, null, null);
                if (cursor.getCount() != 0) {
                    userDB.delete("user", "user_name=?", new String[]{user_name});
                    success.setText(String.format("Successfully delete user %s", user_name));
                }
                else {
                    success.setText(Error.userNameError.getText());
                }
                cursor.close();
            }
        });
        button_backward4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(DeleteUserActivity.this, AdminActivity.class);
                startActivity(intent);
            }
        });
    }

}
