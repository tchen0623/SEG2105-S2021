package seg2105.s2021.studentcoursebookingapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class UpdateCourseActivity  extends AppCompatActivity {

    public String course_code = "", course_name = "";
    private SQLiteDatabase userDB;
    private SQLiteDatabase courseDB;
    boolean by_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_course);
        UserDBHelper userDBHelper = new UserDBHelper(this, "users.db", null, 1);
        CourseDBHelper courseDBHelper = new CourseDBHelper(this, "courses.db", null, 1);
        userDB = userDBHelper.getWritableDatabase();
        courseDB = courseDBHelper.getWritableDatabase();
        TextView admin_mode2 = (TextView) findViewById(R.id.admin_mode2);
        TextView update_course = (TextView) findViewById(R.id.update_course);
        EditText course_code2 = (EditText) findViewById(R.id.course_code2);
        EditText course_name2 = (EditText) findViewById(R.id.course_name2);
        EditText course_code3 = (EditText) findViewById(R.id.course_code3);
        EditText course_name3 = (EditText) findViewById(R.id.course_name3);
        TextView success = (TextView) findViewById(R.id.success2);
        RadioGroup update_menu = (RadioGroup) findViewById(R.id.update_menu);
        update_menu.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.update_by_code:
                        by_name = false;
                        break;
                    case R.id.update_by_name:
                        by_name = true;
                        break;
                }
            }
        });
        Button button_forward1 = (Button) findViewById(R.id.button_forward2);
        Button button_backward1 = (Button) findViewById(R.id.button_backward2);
        button_forward1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (by_name) {
                    course_code = course_code3.getText().toString().trim();
                    course_name = course_name3.getText().toString().trim();
                    Cursor cursor = courseDB.query("course", null, "course_name=?", new String[]{course_name}, null, null, null);
                    if (cursor.getCount() != 0) {
                        ContentValues values = new ContentValues();
                        values.put("course_name", course_name);
                        values.put("course_code", course_code);
                        courseDB.update("course", values,"course_name=?", new String[]{course_name});
                        success.setText(String.format("Successfully update course %s, %s", course_code, course_name));
                    } else {
                        success.setText(Error.courseNameError.getText());
                    }
                    cursor.close();
                } else {
                    course_code = course_code2.getText().toString().trim();
                    course_name = course_name2.getText().toString().trim();
                    Cursor cursor = courseDB.query("course", null, "course_code=?", new String[]{course_code}, null, null, null);
                    if (cursor.getCount() != 0) {
                        ContentValues values = new ContentValues();
                        values.put("course_code", course_code);
                        values.put("course_name", course_name);
                        courseDB.update("course", values,"course_code=?", new String[]{course_code});
                        success.setText(String.format("Successfully update course %s, %s", course_code, course_name));
                    } else {
                        success.setText(Error.courseCodeError.getText());
                    }
                    cursor.close();
                }
            }
        });
        button_backward1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(UpdateCourseActivity.this, AdminActivity.class);
                startActivity(intent);
            }
        });
    }
}