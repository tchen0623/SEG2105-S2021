package seg2105.s2021.studentcoursebookingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class InstructorActivity extends AppCompatActivity {

    private int instructor_task = 0;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor);
        Intent intent = getIntent();
        name = intent.getStringExtra("name");
        TextView instructor_mode = (TextView) findViewById(R.id.instructor_mode);
        TextView welcome_instructor = (TextView) findViewById(R.id.welcome_instructor);
        RadioGroup instructor_menu = (RadioGroup) findViewById(R.id.instructor_menu);

        instructor_menu.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.button_show_all_courses:
                        instructor_task = 1;
                        break;
                    case R.id.button_search_course:
                        instructor_task = 2;
                        break;
                }
            }
        });

        Button button_instructor_task = (Button) findViewById(R.id.button_instructor_task);
        button_instructor_task.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                switch (instructor_task) {
                    case 1:
                        intent.setClass(InstructorActivity.this, ShowAllCoursesActivity.class);
                        break;
                    case 2:
                        intent.setClass(InstructorActivity.this, FindCourseActivity.class);
                        break;
                }
                intent.putExtra("name", name);
                startActivity(intent);
            }
        });

    }
}