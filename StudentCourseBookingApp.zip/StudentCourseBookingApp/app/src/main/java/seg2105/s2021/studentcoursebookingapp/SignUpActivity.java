package seg2105.s2021.studentcoursebookingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String type = intent.getStringExtra("type");
        TextView welcome = (TextView) findViewById(R.id.sign_in_welcome);
        welcome.setText(String.format("Welcome '%s'! You are signed up as '%s'.", name, type));
        Button next = (Button) findViewById(R.id.botton_next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(SignUpActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
