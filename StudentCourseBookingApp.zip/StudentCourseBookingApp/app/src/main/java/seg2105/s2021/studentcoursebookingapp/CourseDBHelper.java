package seg2105.s2021.studentcoursebookingapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class CourseDBHelper extends SQLiteOpenHelper {

    public static final String CREAT_course = "create table course ("
            + "course_id integer primary key autoincrement,"
            + "course_code text,"
            + "course_name text,"
            + "course_instructor text,"
            + "course_date text,"
            + "course_time text,"
            + "course_description text,"
            + "course_capacity integer)";

    public CourseDBHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREAT_course);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
