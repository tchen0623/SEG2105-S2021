package seg2105.s2021.studentcoursebookingapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.SimpleAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FindCourseActivity extends AppCompatActivity {

    public int course_number = -1;
    public String course_code = "", course_name = "";
    private SQLiteDatabase userDB;
    private SQLiteDatabase courseDB;
    private boolean by_name;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_course);
        Intent intent = getIntent();
        name = intent.getStringExtra("name");
        UserDBHelper userDBHelper = new UserDBHelper(this, "users.db", null, 1);
        CourseDBHelper courseDBHelper = new CourseDBHelper(this, "courses.db", null, 1);
        userDB = userDBHelper.getWritableDatabase();
        courseDB = courseDBHelper.getWritableDatabase();
        EditText course_code9 = (EditText) findViewById(R.id.course_code9);
        EditText course_name9 = (EditText) findViewById(R.id.course_name9);

        RadioGroup search_course_menu = (RadioGroup) findViewById(R.id.search_course_menu);
        search_course_menu.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.search_by_code:
                        by_name = false;
                        break;
                    case R.id.search_by_name:
                        by_name = true;
                        break;
                }
            }
        });
        Button button_forward6 = (Button) findViewById(R.id.button_forward6);
        Button button_backward6 = (Button) findViewById(R.id.button_backward6);
        Button button_search_result = (Button) findViewById(R.id.search_result);


        ListView list_search_result = (ListView) findViewById(R.id.list_search_result);
        List<Map<String, Object>> listItemsList = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("number", "number");
        map.put("code", "code");
        map.put("name", "name");
        listItemsList.add(map);

        SimpleAdapter adapter = new SimpleAdapter(this, listItemsList, R.layout.list_course, new String[]{"number", "code", "name"}, new int[]{R.id.data_course_number, R.id.data_course_code, R.id.data_course_name});

        button_search_result.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Recycle")
            @Override
            public void onClick(View v) {
                course_number = -1;
                listItemsList.clear();
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("number", "number");
                map.put("code", "code");
                map.put("name", "name");
                listItemsList.add(map);
                Cursor cursor;
                if (by_name) {
                    course_name = course_name9.getText().toString().trim();
                    cursor = courseDB.query("course", null, "course_name=?", new String[]{course_name}, null, null, null);
                }
                else {
                    course_code = course_code9.getText().toString().trim();
                    cursor = courseDB.query("course", null, "course_code=?", new String[]{course_code}, null, null, null);
                }
                while (cursor.moveToNext()) {
                    course_number = cursor.getInt(0);
                    map = new HashMap<String, Object>();
                    map.put("number", cursor.getString(0));
                    map.put("code", cursor.getString(1));
                    map.put("name", cursor.getString(2));
                    listItemsList.add(map);
                }
                cursor.close();
                list_search_result.setAdapter(adapter);
            }
        });

        button_forward6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                if (course_number == -1) {
                    intent.setClass(FindCourseActivity.this, ErrorActivity.class);
                    intent.putExtra("error", Error.searchCourseError.getText());
                }
                else {
                    intent.setClass(FindCourseActivity.this, CourseActivity.class);
                    intent.putExtra("course_number", course_number);
                    intent.putExtra("name", name);
                }
                startActivity(intent);
            }
        });

        button_backward6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(FindCourseActivity.this, InstructorActivity.class);
                startActivity(intent);
            }
        });

        list_search_result.setAdapter(adapter);

    }


}
