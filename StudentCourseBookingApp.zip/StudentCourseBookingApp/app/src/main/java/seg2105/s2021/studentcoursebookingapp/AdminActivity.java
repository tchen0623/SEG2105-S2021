package seg2105.s2021.studentcoursebookingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AdminActivity extends AppCompatActivity {

    private int admin_task = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        TextView admin_mode = (TextView) findViewById(R.id.admin_mode);
        TextView welcome_admin = (TextView) findViewById(R.id.welcome_admin);
        RadioGroup admin_menu = (RadioGroup) findViewById(R.id.admin_menu);

        admin_menu.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.button_create_course:
                        admin_task = 1;
                        break;
                    case R.id.button_show_all_courses:
                        admin_task = 2;
                        break;
                    case R.id.button_search_course:
                        admin_task = 3;
                        break;
                    case R.id.button_delete_user:
                        admin_task = 4;
                        break;
                }
            }
        });

        Button button_admin_task = (Button) findViewById(R.id.button_admin_task);
        button_admin_task.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                switch (admin_task) {
                    case 1:
                        intent.setClass(AdminActivity.this, CreateCourseActivity.class);
                        break;
                    case 2:
                        intent.setClass(AdminActivity.this, UpdateCourseActivity.class);
                        break;
                    case 3:
                        intent.setClass(AdminActivity.this, DeleteCourseActivity.class);
                        break;
                    case 4:
                        intent.setClass(AdminActivity.this, DeleteUserActivity.class);
                        break;
                }
                startActivity(intent);
            }
        });
    }
}
