package seg2105.s2021.studentcoursebookingapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CourseActivity extends AppCompatActivity {

    private int course_number;
    private SQLiteDatabase userDB;
    private SQLiteDatabase courseDB;
    private String name;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course);

        TextView success = (TextView) findViewById(R.id.success1);

        TextView text_course_code = (TextView) findViewById(R.id.text_course_code);
        TextView text_course_name = (TextView) findViewById(R.id.text_course_name);
        TextView text_course_instructor = (TextView) findViewById(R.id.text_course_instructor);
        TextView text_course_date = (TextView) findViewById(R.id.text_course_date);
        TextView text_course_time = (TextView) findViewById(R.id.text_course_time);
        TextView text_course_description = (TextView) findViewById(R.id.text_course_description);
        TextView text_course_capacity = (TextView) findViewById(R.id.text_course_capacity);

        text_course_code.setVisibility(View.VISIBLE);
        text_course_name.setVisibility(View.VISIBLE);
        text_course_instructor.setVisibility(View.VISIBLE);
        text_course_date.setVisibility(View.VISIBLE);
        text_course_time.setVisibility(View.VISIBLE);
        text_course_description.setVisibility(View.VISIBLE);
        text_course_capacity.setVisibility(View.VISIBLE);

        EditText info_course_code = (EditText) findViewById(R.id.info_course_code);
        EditText info_course_name = (EditText) findViewById(R.id.info_course_name);
        EditText info_course_instructor = (EditText) findViewById(R.id.info_course_instructor);
        EditText info_course_date = (EditText) findViewById(R.id.info_course_date);
        EditText info_course_time = (EditText) findViewById(R.id.info_course_time);
        EditText info_course_description = (EditText) findViewById(R.id.info_course_description);
        EditText info_course_capacity = (EditText) findViewById(R.id.info_course_capacity);
        Button assign = (Button) findViewById(R.id.assign);
        Button modify = (Button) findViewById(R.id.modify);
        Button unassign = (Button) findViewById(R.id.unassign);
        Button save = (Button) findViewById(R.id.save);
        Button backward7 = (Button) findViewById(R.id.button_backward7);

        info_course_code.setFocusableInTouchMode(false);
        info_course_code.setFocusable(false);
        info_course_name.setFocusableInTouchMode(false);
        info_course_name.setFocusable(false);
        info_course_instructor.setFocusableInTouchMode(false);
        info_course_instructor.setFocusable(false);
        info_course_date.setFocusableInTouchMode(false);
        info_course_date.setFocusable(false);
        info_course_time.setFocusableInTouchMode(false);
        info_course_time.setFocusable(false);
        info_course_description.setFocusableInTouchMode(false);
        info_course_description.setFocusable(false);
        info_course_capacity.setFocusableInTouchMode(false);
        info_course_capacity.setFocusable(false);

        Intent intent = getIntent();
        name = intent.getStringExtra("name");
        course_number = intent.getIntExtra("course_number", -1);
        success.setText(String.format("Current User is %s", name));

        UserDBHelper userDBHelper = new UserDBHelper(this, "users.db", null, 1);
        CourseDBHelper courseDBHelper = new CourseDBHelper(this, "courses.db", null, 1);
        userDB = userDBHelper.getWritableDatabase();
        courseDB = courseDBHelper.getWritableDatabase();

        @SuppressLint("Recycle") Cursor cursor = courseDB.query("course", null, "course_id=?", new String[]{Integer.toString(course_number)}, null, null, null);
        cursor.moveToFirst();
        info_course_code.setText(cursor.getString(1));
        info_course_name.setText(cursor.getString(2));
        if (!cursor.isNull(3)) {
            info_course_instructor.setText(cursor.getString(3));
        }
        if (!cursor.isNull(4)) {
            info_course_date.setText(cursor.getString(4));
        }
        if (!cursor.isNull(5)) {
            info_course_time.setText(cursor.getString(5));
        }
        if (!cursor.isNull(6)) {
            info_course_description.setText(cursor.getString(6));
        }
        if (!cursor.isNull(7)) {
            info_course_capacity.setText(Integer.toString(cursor.getInt(7)));
        }

        backward7.setVisibility(View.VISIBLE);
        if (cursor.isNull(3)) {
            assign.setVisibility(View.VISIBLE);
            modify.setVisibility(View.GONE);
            unassign.setVisibility(View.GONE);
            save.setVisibility(View.GONE);
        } else if (name.equals(cursor.getString(3))){
            assign.setVisibility(View.GONE);
            modify.setVisibility(View.VISIBLE);
            unassign.setVisibility(View.VISIBLE);
            save.setVisibility(View.GONE);
        } else {
            assign.setVisibility(View.GONE);
            modify.setVisibility(View.GONE);
            unassign.setVisibility(View.GONE);
            save.setVisibility(View.GONE);
        }

        assign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContentValues values = new ContentValues();
                String instructorname = info_course_instructor.getText().toString().trim();
                if (!instructorname.equals(""))
                {
                    success.setText(String.format("Course has been assigned to %s", instructorname));
                }
                else
                {
                    values.put("course_instructor", name);
                    courseDB.update("course", values, "course_id=?", new String[]{Integer.toString(course_number)});
                    assign.setVisibility(View.GONE);
                    modify.setVisibility(View.VISIBLE);
                    unassign.setVisibility(View.VISIBLE);
                    save.setVisibility(View.GONE);
                    success.setText(String.format("Successfully assign course to %s", name));
                }
            }
        });

        modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                info_course_date.setFocusable(true);
                info_course_date.setFocusableInTouchMode(true);
                info_course_time.setFocusable(true);
                info_course_time.setFocusableInTouchMode(true);
                info_course_description.setFocusable(true);
                info_course_description.setFocusableInTouchMode(true);
                info_course_capacity.setFocusable(true);
                info_course_capacity.setFocusableInTouchMode(true);
                modify.setVisibility(View.GONE);
                unassign.setVisibility(View.GONE);
                save.setVisibility(View.VISIBLE);
            }
        });

        unassign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContentValues values = new ContentValues();
                values.put("course_instructor", (String) null);
                values.put("course_date", (String) null);
                values.put("course_time", (String) null);
                values.put("course_description", (String) null);
                values.put("course_capacity", (Integer) null);
                courseDB.update("course", values, "course_id=?", new String[]{Integer.toString(course_number)});
                success.setText(String.format("Successfully unassign course to %s", name));
                assign.setVisibility(View.VISIBLE);
                modify.setVisibility(View.GONE);
                unassign.setVisibility(View.GONE);
                save.setVisibility(View.GONE);
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContentValues values = new ContentValues();
                values.put("course_instructor", info_course_instructor.getText().toString().trim());
                values.put("course_date", info_course_date.getText().toString().trim());
                values.put("course_time", info_course_time.getText().toString().trim());
                values.put("course_description", info_course_description.getText().toString().trim());
                values.put("course_capacity", info_course_capacity.getText().toString().trim());
                courseDB.update("course", values, "course_id=?", new String[]{Integer.toString(course_number)});
                assign.setVisibility(View.GONE);
                modify.setVisibility(View.VISIBLE);
                unassign.setVisibility(View.VISIBLE);
                save.setVisibility(View.GONE);
            }
        });

        backward7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(CourseActivity.this, FindCourseActivity.class);
                intent.putExtra("name", name);
                startActivity(intent);
            }
        });

    }

}
