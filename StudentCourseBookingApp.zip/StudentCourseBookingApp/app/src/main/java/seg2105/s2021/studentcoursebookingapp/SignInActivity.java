package seg2105.s2021.studentcoursebookingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SignInActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String type = intent.getStringExtra("type");
        TextView welcome = (TextView) findViewById(R.id.sign_in_welcome);
        welcome.setText(String.format("Welcome '%s'! You are logged in as '%s'.", name, type));
        Button next = (Button) findViewById(R.id.botton_next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                switch (type) {
                    case "admin":
                        intent.setClass(SignInActivity.this, AdminActivity.class);
                        break;
                    case "instructor":
                        intent.setClass(SignInActivity.this, InstructorActivity.class);
                        intent.putExtra("name", name);
                        break;
                    case "student":
                        intent.setClass(SignInActivity.this, StudentActivity.class);
                        break;
                }
                startActivity(intent);
            }
        });
    }
}
